import 'package:flutter/material.dart';
import 'package:harmonica/shared/widgets/stack.dart';

class HomePage2 extends StatefulWidget {
  const HomePage2({super.key});

  @override
  State<HomePage2> createState() => _HomePage2State();
}

class _HomePage2State extends State<HomePage2> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          leading: const Icon(Icons.notifications),
          title: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Chip(
                label: Text("Music"),
              ),
              Chip(
                label: Text("Podcast"),
              ),
            ],
          ),
          centerTitle: true,
          actions: const [Icon(Icons.settings)],
        ),
        body: Column(
          children: [
            Row(
              children: [
                Text(
                  "Trending Playlists",
                  style: TextStyle(
                    fontSize: 25,
                  ),
                ),
                Spacer(),
                Chip(label: Text("SEE MORE")),
              ],
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.25,
              child: ListView(
                // physics list ko kheechne deti he with certain effects as mentioned in the names
                physics: BouncingScrollPhysics(),
                scrollDirection: Axis.horizontal,
                children: [
                  SongStack(),
                  SongStack(),
                  SongStack(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
